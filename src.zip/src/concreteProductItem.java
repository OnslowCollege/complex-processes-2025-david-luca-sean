
public class concreteProductItem extends ProductItem {
  public concreteProductItem(int productID, String name, float price, int inStore, String imageName) {
    super(productID, name, price, inStore, imageName);
  }
}
