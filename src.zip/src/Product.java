//package Checkout;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Product {

    public static void addToPanelWith(final String imageFile,
    final String name,
    final double price,
    final JPanel productPanel,
    final int quantity) {        
        JLabel qtyLabel = new JLabel("Number: " + quantity);
        qtyLabel.setFont(new Font("Serif", Font.BOLD, 14));
        qtyLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        productPanel.add(qtyLabel);

        ImageIcon icon = new ImageIcon(imageFile); 
        JLabel imageLabel = new JLabel(icon);
        imageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        productPanel.add(imageLabel);

        //text
        JLabel textLabel = new JLabel(name + " - $" + price);
        textLabel.setFont(new Font("Serif", Font.PLAIN, 16));

        //scale cart to 10% of the product 
        //int cartWidth = icon.getIconWidth() / 10;
        //int cartHeight = icon.getIconHeight() / 10;
        //infoPanel.add(cartLabel);
        ImageIcon cartIcon = new ImageIcon("cart.jpg");
        Image original = cartIcon.getImage();
        Image scaled = original.getScaledInstance(40, 40, Image.SCALE_SMOOTH);
        ImageIcon smallCartIcon = new ImageIcon(scaled);
        JButton cartButtton = new JButton(smallCartIcon);
        //JLabel cartLabel = new JLabel(new ImageIcon(cartImg));


        //info panel
        JPanel infoPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 0));
        infoPanel.setOpaque(false);
        infoPanel.setAlignmentX(Component.CENTER_ALIGNMENT); 

        infoPanel.add(textLabel);
        infoPanel.add(cartButtton);

        productPanel.add(infoPanel);

        cartButtton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Application1.addToCart(name, price, quantity);
            }
        });
    }
}
